package com.boot.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.boot.beans.Emp;


//@Repository
public class EmpRepositoryImpl1 implements EmpRepository {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(Integer arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Emp arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Iterable<? extends Emp> arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean exists(Integer arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<Emp> findAll() {
		/*ArrayList<Emp> empList = new ArrayList<>();
		
		empList.add(new Emp());
		empList.add(new Emp());
		empList.add(new Emp());*/
		String sql = "SELECT e FROM emp e";
		Query qry = entityManager.createQuery(sql);
		
		List<Emp> empList = qry.getResultList();
		
		return empList;
	}

	@Override
	public Iterable<Emp> findAll(Iterable<Integer> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Emp findOne(Integer arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Emp> S save(S arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Emp> Iterable<S> save(Iterable<S> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
