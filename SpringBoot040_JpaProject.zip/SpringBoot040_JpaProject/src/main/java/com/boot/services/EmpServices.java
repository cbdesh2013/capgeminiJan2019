package com.boot.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.beans.Emp;
import com.boot.repositories.EmpRepository;

@Service
public class EmpServices {
	@Autowired
	private EmpRepository dao;
	
	public List<Emp> getAllEmps(){  
        List<Emp> empList = new ArrayList<>();  
        dao.findAll().forEach(empList::add);  
        return empList;  
    }  
    /*public Optional<UserRecord> getUser(String id){  
        returnuserRepository.findOne(id);  
    }  
    publicvoid addUser(UserRecord userRecord){  
        userRepository.save(userRecord);  
    }  
    publicvoid delete(String id){  
        userRepository.delete(id);  
    }  */
}	
