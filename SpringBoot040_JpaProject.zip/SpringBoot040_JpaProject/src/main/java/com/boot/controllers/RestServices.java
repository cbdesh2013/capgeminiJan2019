package com.boot.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.beans.Emp;
import com.boot.services.EmpServices; 

@RestController 
public class RestServices {
	@Autowired  
    private EmpServices services;   
	
	public RestServices(){
		System.out.println("Bean created.");
	}
	@RequestMapping("/listAll")  
    public List<Emp> getAllEmps(){  
		return services.getAllEmps(); 
    } 
}
