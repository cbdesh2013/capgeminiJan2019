import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Java8Code040Functional035FilePath {

	public static void main(String[] args) throws IOException {
		
			/*
			// Old way
			File file = new File(".");
			String[] fileList = file.list();
			System.out.println("Total files in directory: " + fileList.length);
			for(String fileName : fileList){
				System.out.println(fileName);
			}
			*/
			/*
			// Using Lambda expression for all files
			Files.list(Paths.get(".")).forEach(System.out::println);
			*/
			///*
			// Using filter for directories only
			Files.list(Paths.get(".")).filter(Files::isDirectory).forEach(System.out::println);
			//*/
			/*
			// Old way: Using Regex on Filter
			final String[] fileList = new File(".\\src").list(
					new FilenameFilter() {
						public boolean accept(final File dir, final String name) {
							//return name.startsWith("Java8Code030Functional");
							return name.endsWith(".java");
					}
				});
			for(String fileName : fileList){
				System.out.println(fileName);
			}
			*/
			/*
			// Using filter for RegeX
			Files.newDirectoryStream(Paths.get(".\\src"), path -> path.toString().startsWith(".\\src\\Java8Code040Functional")).forEach(System.out::println);
			//Files.newDirectoryStream(Paths.get(".\\src"), path -> path.toString().endsWith(".java")).forEach(System.out::println);
			*/
			/*
			// List hidden files
			final File[] files = new File("c:\\").listFiles(file -> file.isHidden()); // File::isHidden
			for(File file : files){
				System.out.println(file.getName());
			}
			*/
			/*
			// Listing immediate sub directories using Rudimentary approach
			List<File> files = new ArrayList<>();
			File[] filesInCurerentDir = new File(".\\src").listFiles();
			for(File file : filesInCurerentDir) {
				File[] filesInSubDir = file.listFiles();
				if(filesInSubDir != null) {
					files.addAll(Arrays.asList(filesInSubDir));
				} else {
					files.add(file);
				}
			}
			System.out.println("Count of files: " + files.size());
			*/
			/*// Listing immediate sub directories using flatMap
			List<File> files = Stream.of(new File(".\\src").listFiles())
					.flatMap(file -> file.listFiles() == null ?
					Stream.of(file) : Stream.of(file.listFiles()))
					.collect(Collectors.toList());
			System.out.println("Count of files: " + files.size());
			*/
		
	}

}
