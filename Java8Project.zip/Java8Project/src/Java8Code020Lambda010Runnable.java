import java.util.concurrent.Executors;

public class Java8Code020Lambda010Runnable {

	public static void main(String[] argv){

		/*
		// Using Inner class...
		Runnable r = new Runnable(){

			@Override
			public void run(){
				System.out.println("hello Inner class1");
				System.out.println("hello Inner class2");
			}
		};
		*/
		///*
		// Using Lambda expression
		Runnable r = () -> { 
			System.out.println("hello lambda1!");
			System.out.println("hello lambda2!");
		};
		//*/


		Thread t = new Thread(r);
		t.start();
		
		Executors.newSingleThreadExecutor().execute(r);
	}
}