import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

public class Java8Code040Functional021SimpleTransform {
	private static List<String> monthNames = Arrays.asList("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec");
	
	public static void main(String[] args) {
		final List<String> uppercaseNames = new ArrayList<String>();

		/*
		for(String name : monthNames) {
			uppercaseNames.add(name.toUpperCase());
		}
		
		for(String name : uppercaseNames){
			System.out.println(name);
		}
		*/
		/*
		monthNames.forEach(name -> uppercaseNames.add(name.toUpperCase()));
		uppercaseNames.forEach(System.out::println);
		//uppercaseNames.forEach(name -> {System.out.println("Data: " + name);});
		//*/
		///*// The stream() is available in each collection and it wraps the collection into instance of Stream like an iterator.
		  // The map() transforms input collection to output collection. It ensures same number of elements that of input collection 
		  //  	to exist in output collection.  For each element it applies transformation given by Lambda Expression.
		monthNames.stream().map(name -> name.toUpperCase()).forEach(name -> System.out.println(name));
		//*/
		
		// Following statements use method reference.
		//monthNames.stream().map(String::toUpperCase).forEach(System.out::println);
		
		// Transformation from String to int
		//monthNames.stream().map(String::length).forEach(System.out::println);
		
		List<List<String>> listList = new ArrayList<>();
		List<String> list1 = Arrays.asList("a", "b", "c");
		List<String> list2 = Arrays.asList("d", "e");
		List<String> list3 = Arrays.asList("f", "i", "j", "k");
		
		listList.add(list1);
		listList.add(list2);
		listList.add(list3);
		
		Stream<List<String>> modiList = listList.stream().map(list -> {
			List<String> newList = new ArrayList<>(list);
			newList.add("x");
			return newList;
		});
		
		modiList.forEach(System.out::println);
	}
}
