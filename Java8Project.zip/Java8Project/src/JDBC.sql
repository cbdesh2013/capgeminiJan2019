CREATE OR REPLACE PROCEDURE getEmpCursor(p_sal IN varchar2,  cur_emp OUT SYS_REFCURSOR)
IS
BEGIN
 
  OPEN cur_emp FOR
  SELECT * FROM Emp WHERE sal >= p_sal;
 
END;

--------------------------------------------------------------------

CREATE OR REPLACE FUNCTION getAllEmps RETURN SYS_REFCURSOR 
 AS 
     my_cursor SYS_REFCURSOR; 
 BEGIN 
     OPEN my_cursor FOR 
         SELECT EMPNO,ENAME,SAL FROM scott.emp; 
     RETURN  my_cursor; 
  END;
