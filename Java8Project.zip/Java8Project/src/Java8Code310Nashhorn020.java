
public class Java8Code310Nashhorn020 {

	public static void main(String[] args) {
		

	}
}
