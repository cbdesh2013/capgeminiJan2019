import java.util.Arrays;
import java.util.Comparator;

public class Java8Code020Lambda020Comparator {

	public static void main(String[] argv){

		/*
		// Using Inner class...
		Comparator<Integer> c = new Comparator<Integer>(){

			@Override
			public int compare(Integer val1, Integer val2){
					
					return (val1<val2)? 1 : (val1==val2)? 0 : -1;
			}
		};
		*/
		///*
		// Using Lambda expression
		Comparator<Integer> c = (val1, val2) -> {
			return (val1<val2)? -1 : (val1==val2)? 0 : 1;
		};
		
		//*/

		int val1=7, val2=8;

		System.out.println(c.compare(val1, val2));
		
		Integer[] intArray = { new Integer(6), new Integer(12), new Integer(9), new Integer(7), new Integer(15)};
		
		//Arrays.sort(intArray, new MyComparator());
		Arrays.sort(intArray, c);
		for (Integer integer : intArray) {
			System.out.println(integer);
		}
	}
}

class MyComparator implements Comparator<Integer>{

	@Override
	public int compare(Integer val1, Integer val2) {
		return (val1<val2)? -1 : (val1==val2)? 0 : 1;
	}
	
}