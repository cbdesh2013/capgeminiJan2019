
public class Java8Code010Hello {

	public static void main(String[] argv){

		System.out.println("Hello-Java 8");
	}
}