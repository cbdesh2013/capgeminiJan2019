import java.util.function.Supplier;

public class Java8Code040Functional041DelayInitSupplier {

	public static void main(String[] args) {
		Holder holder = new Holder();
		System.out.println("Demanding object");
		holder.getHeavy();
	}
}

class Holder {
	// Eager creation...
	//Heavy2 heavy = new Heavy2();
	
	// Lazy creation. The supplier type of reference ensures lazy creation of object Heavy.
	//Supplier<Heavy2> heavy = Heavy2::new;
	
	// Postpone and cache instance.  The Supplier type of reference routes execution to the createAndCacheHeavy() only on demand.
	// This approach is thread safe as createAndCacheHeavy() is synchronized.
	private Supplier<Heavy2> heavy = () -> createAndCacheHeavy();
	
	public Holder() {
		System.out.println("Holder created");
	}
	public Heavy2 getHeavy() {
		// Uncomment for eager creation.
		//return heavy;
		
		// Uncomment for Lazy creation.
		return heavy.get();
	}
	
	private synchronized Heavy2 createAndCacheHeavy() {
		class HeavyFactory implements Supplier<Heavy2> {
			private final Heavy2 heavyInstance = new Heavy2();
			public Heavy2 get() {
				return heavyInstance;
			}
		}
		if(!HeavyFactory.class.isInstance(heavy)) {
			heavy = new HeavyFactory();
		}
		
		return heavy.get();
	}
}


class Heavy2 {
	public Heavy2() { 
		System.out.println("Heavy created");
	}
	public String toString() {
		return "quite heavy";
	}
}