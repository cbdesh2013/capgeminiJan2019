import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.annotation.NonNull;

import org.eclipse.jdt.annotation.NonNull;

public class Java8Code060TypedAnnotations {
	@ NonNull 
	private String x; //@ NonNull 
	
	@NonNull
	List<@NonNull String> list = new ArrayList<>();
	
	public Java8Code060TypedAnnotations(String x) {
		super();
		this.x = x;
	}
	
public Java8Code060TypedAnnotations() {
	super();
	x = "";}

	public String getX() {
		return x;
	}

	public void setX(String x) {
		this.x = x;
	}

	public Integer division(Integer numerator, @ NonNull Integer denominator){
		return numerator/denominator;
	}
	public static void main(String[] args) {
		Java8Code060TypedAnnotations obj = new Java8Code060TypedAnnotations(null);
		//Java8Code060TypedAnnotations obj = new Java8Code060TypedAnnotations();
		obj.setX("aaa");
		System.out.println(obj.x.length());
		
		//Integer result = obj.division(10, 0);
		//System.out.println(result);
		
		obj.list = null;
		
	}

}
