interface MyProcessor {
	String process(String value);
}

public class Java8Code020Lambda030Custom {

	public String execute(MyProcessor processor){
		return processor.process("Hello");
	}

	public static void main(String[] args) {
	Java8Code020Lambda030Custom executor = 
		new Java8Code020Lambda030Custom();
		/*
		// Implementation of SAM interface.
		MyProcessor processor = new MyProcessor() {
			@Override
			public String process(String value) {
				String msg = "AnnClass: "+value;
				return msg;
			}
		};
		System.out.println(executor.execute(processor));
		*/

		/*
		// Syntax 1
		MyProcessor processor = (param) -> {
			String msg = "Syntax1: "+param;
			return msg;
		};
		System.out.println(executor.execute(processor));
		*/

		///*
		// Syntax2
		String msg2 = executor.execute((param)-> {
			String msg = "Syntax2: "+param;
			return msg;
		});
		System.out.println(msg2);
		//*/
	}
}