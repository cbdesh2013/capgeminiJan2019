import sun.applet.Main;

public class Java8Code065Streams {

	public static void main(String[] args) {
		
	}
}
