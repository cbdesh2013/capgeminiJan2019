import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

public class Java8Code110Adjuster {

	public static void main(String[] args) {
		// Adjusters with LocalDate/LocalDateTime
		LocalDate localDate0 = LocalDate.now();
		System.out.println("Current Local date: " + localDate0);
		
		// The Plus adjuster
		LocalDate threeMonthLater = localDate0.plusMonths(3);
		System.out.println("Case I.I LocalDate + 3 Months: " + threeMonthLater);
		
		// Adding days in Date
		LocalDate threeDaysLater = localDate0.plusDays(3);
		System.out.println("Case I.II LocalDate + 3 Days: " + threeDaysLater);
		
		// Adding year in Date
		LocalDate threeYearsLater = localDate0.plusYears(3);
		System.out.println("Case I.III LocalDate + 3 Years: " + threeYearsLater);
		
		// Adding an year in a 29th Feb of leap year
		String stringDate1 = "29/02/2016";// time not required.
		DateTimeFormatter formatter1 = DateTimeFormatter .ofPattern("dd/MM/yyyy");// must match the format of string input
											
		LocalDate leapYrDate = LocalDate.parse(stringDate1, formatter1);
		LocalDate oneYearLater = leapYrDate.plusYears(1);
		System.out.println("Case I.IV Leap year LocalDate + 1 Year: " + oneYearLater);
		
		// Subtracting month in date
		LocalDate threeMonthsBefore = localDate0.minusMonths(3);
		System.out.println("Case I.V LocalDate - 3 Months: " + threeMonthsBefore);

		System.out.println("The 'with' adjuster *****************");
		
		LocalDate localDate1 = LocalDate.now().with(TemporalAdjusters.firstDayOfMonth());
		System.out.println("Case II.I LocalDate - First day of month: " + localDate1);
		
		LocalDate localDate2 = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
		System.out.println("Case II.II LocalDate - Last day of month: " + localDate2);
		
		LocalDate localDate3 = LocalDate.now().with(TemporalAdjusters.firstInMonth(DayOfWeek.SATURDAY));
		System.out.println("Case II.III LocalDate - First Saturday of month: " + localDate3);
		
		LocalDate localDate4 = LocalDate.now().with(TemporalAdjusters.firstInMonth(DayOfWeek.SATURDAY)).plusWeeks(1);
		System.out.println("Case II.IV LocalDate - Second Saturday of month: " + localDate4);
		
		LocalDate localDate5 = LocalDate.now().with(TemporalAdjusters.firstInMonth(DayOfWeek.SATURDAY)).plusWeeks(3);
		System.out.println("Case II.V LocalDate - Fourth Saturday of month: " + localDate5);
		
		LocalDate localDate6 = LocalDate.now().with(TemporalAdjusters.lastInMonth(DayOfWeek.SUNDAY));
		System.out.println("Case II.VI LocalDate - Last Sunday of month: " + localDate6);
		
		LocalDate localDate7 = LocalDate.now().plusMonths(1).with(TemporalAdjusters.firstInMonth(DayOfWeek.SUNDAY));
		System.out.println("Case II.VII LocalDate - First Sunday of next month: " + localDate7);
		
	}

}
