import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Java8Code070ParallelStream {

	public static void main(String[] args) {

		long t1, t2;
		List<Employee> eList = new ArrayList<Employee>();
		for(int i=0; i<100; i++) {
			eList.add(new Employee(1001, 20000, 10));
			eList.add(new Employee(1009, 3000, 20));
			eList.add(new Employee(1006, 15002, 30));
			eList.add(new Employee(1003, 7856, 40)); 
			eList.add(new Employee(1002, 200, 50)); 
			eList.add(new Employee(1004, 50000, 60));
		}

		/***** Here We Are Creating A 'Sequential Stream' & Displaying The Result *****/
		t1 = System.currentTimeMillis();   
		System.out.println("Sequential Stream Count?= " + eList.stream().filter(e -> e.getEmpSal() > 15000).count());

		t2 = System.currentTimeMillis();
		System.out.println("Sequential Stream Time Taken?= " + (t2-t1) + "\n");

		/***** Here We Are Creating A 'Parallel Stream' & Displaying The Result *****/
		t1 = System.currentTimeMillis();		
		System.out.println("Parallel Stream Count?= " + eList.parallelStream().filter(e -> e.getEmpSal() > 15000).count());

		t2 = System.currentTimeMillis();
		System.out.println("Parallel Stream Time Taken?= " + (t2-t1));
		
		Stream<Employee> pStream = eList.stream().parallel();
	}
}