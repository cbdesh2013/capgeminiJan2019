import java.util.List;
import java.util.ArrayList;
import java.util.stream.Stream;

public class Java8Code050FilterMapReduce010Filter{
	private List<Integer> list;

	public Java8Code050FilterMapReduce010Filter(){
		list = new ArrayList<>();
		list.add(10);
		list.add(30);
		list.add(20);
		list.add(50);
		list.add(70);
	}
	public static void main(String[] argv){
		
		Java8Code050FilterMapReduce010Filter listInt = new Java8Code050FilterMapReduce010Filter();
		Stream<Integer> numOver30 = listInt.list.stream().filter(p->p >30);
		numOver30.forEach(System.out::println);
	}
}