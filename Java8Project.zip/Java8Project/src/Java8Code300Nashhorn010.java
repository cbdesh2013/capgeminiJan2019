
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.time.LocalDateTime;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/*
 * http://winterbe.com/posts/2014/04/05/java8-nashorn-tutorial/
 */
public class Java8Code300Nashhorn010 {

	public static void main(String[] args) {
		ScriptEngine engine = new ScriptEngineManager().getEngineByName("nashorn");
		
		/*
		try {
			engine.eval("print('Hello World!');");
		} catch (ScriptException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		/*// Invoke Javascript function in Java
		try {
			engine.eval(new FileReader("F:\\CoreJava\\Java 8\\Java8Project\\src\\script.js"));

			Invocable invocable = (Invocable) engine;

			String result = (String)invocable.invokeFunction("fun1", "Chandra Deshpande");
			System.out.println(result);
			
		} catch (FileNotFoundException | NoSuchMethodException | ScriptException e) {
			e.printStackTrace();
		}
		*/
		/*// Pass Java object to Javascript function.
		try {
			engine.eval(new FileReader("F:\\CoreJava\\Java 8\\Java8Project\\src\\script.js"));

			Invocable invocable = (Invocable) engine;

			invocable.invokeFunction("fun2", LocalDateTime.now());
			invocable.invokeFunction("fun2", new Empp(100, "xxx", 5000));
			
		} catch (FileNotFoundException | NoSuchMethodException | ScriptException e) {
			e.printStackTrace();
		}
		*/
		
		///*// Invoke Javascript function in Java and Java Function in JavaScript
		try {
			engine.eval(new FileReader("F:\\CoreJava\\Java 8\\Java8Project\\src\\script.js"));

			Invocable invocable = (Invocable) engine;

			String result = (String)invocable.invokeFunction("fun3", "Chandra Deshpande");
			System.out.println(result);
			
		} catch (FileNotFoundException | NoSuchMethodException | ScriptException e) {
			e.printStackTrace();
		}
		//*/
	}
	
	public static String javaMethod(String name) {
	    System.out.format("Hi there from Java, %s", name);
	    return "\ngreetings from java";
	}

}

class Empp {
	private int empNo;
	private String empNm;
	private float empSal;
	
	public Empp() {}
	
	public Empp(int empNo, String empNm, float empSal) {
		super();
		this.empNo = empNo;
		this.empNm = empNm;
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal=" + empSal + "]";
	}
}