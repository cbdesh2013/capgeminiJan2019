import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Java8Code040Functional025JoinCollection {
	private static List<String> monthNames = Arrays.asList("january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december");
	
	public static void main(String[] args) {
		///*
		// Old approach: Code to print month names separated by comma.
		// Observe, unnecessary comma appearing at last.
		System.out.print("Old approach-1 :");
		for(String name : monthNames) {
			System.out.print(name + ", ");
		}
		System.out.println();
		//*/
		///*
		// Old approach: Code to print month names separated by comma.
		// Observe, comma disappeared at last. 
		System.out.print("Old approach-2 :");
		for(int index=0; index<monthNames.size()-1; index++) {
			System.out.print(monthNames.get(index) + ", ");
		}
		System.out.println(monthNames.get(monthNames.size()-1));
		//*/
		// join approach
		
		System.out.println("Join approach: " + String.join(", ", monthNames));
		
		// Join approach with Map
		System.out.print("Join approach with map :");
		System.out.println(
				monthNames.stream().map(String::toUpperCase).collect(Collectors.joining(", ")));
		
	}

}
