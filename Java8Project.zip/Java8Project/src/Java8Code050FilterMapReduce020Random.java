import java.util.Random;

public class Java8Code050FilterMapReduce020Random{
	public static void main(String[] argv){
		
	new Random()
.ints() // generate a stream of random integers
.limit(10) // we only need 10 random numbers
.forEach(System.out::println);
	}
}