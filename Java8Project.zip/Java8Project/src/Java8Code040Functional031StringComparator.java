import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Java8Code040Functional031StringComparator {
	private List<Person> people = null;
	
	public Java8Code040Functional031StringComparator(){
		people = Arrays.asList(
				new Person("John", 21),
				new Person("Sara", 35),
				new Person("Jane", 20),
				new Person("Greg", 19));
	}
	
	public static void main(String[] args) {
		Java8Code040Functional031StringComparator appl = new Java8Code040Functional031StringComparator();
		/*
		// The sorted() runs on stream and takes parameter of type Comparator
		List<Person> ascendingAge = appl.people.stream()
				.sorted((person1, person2) -> person1.ageDifference(person2))
				.collect(Collectors.toList());
		*/
		/*
		List<Person> ascendingAge = appl.people.stream().sorted(Person::ageDifference).collect(Collectors.toList());
		*/
		/*
		Comparator<Person> compareAscending = (person1, person2) -> person1.ageDifference(person2);
		Comparator<Person> compareDescending = compareAscending.reversed();
		
		List<Person> ascendingAge = appl.people.stream().sorted(compareAscending).collect(Collectors.toList());
		//List<Person> ascendingAge = appl.people.stream().sorted(compareDescending).collect(Collectors.toList());
		*/
		/*
		List<Person> ascendingAge = appl.people.stream()
				.sorted((person1, person2) -> person1.getName().compareTo(person2.getName()))
				.collect(Collectors.toList());
		
		ascendingAge.forEach(System.out::println);
		*/
		//***********************************************
		/*
		appl.people.stream()
		.max(Person::ageDifference)
		.ifPresent(eldest -> System.out.println("Eldest: " + eldest));
		*/
		///*
		// Multiple comparisons
		final Function<Person, Integer> byAge = person -> person.getAge();
		final Function<Person, String> byTheirName = person -> person.getName();
		
		List<Person> ascendingAge = appl.people.stream()
		.sorted(Comparator.comparing(byAge).thenComparing(byTheirName))
		.collect(Collectors.toList());
		//*/
		ascendingAge.forEach(System.out::println);
	}
}

class Person {
	private final String name;
	private final int age;
	public Person(final String theName, final int theAge) {
		name = theName;
		age = theAge;
	}
	public String getName() { return name; }
	public int getAge() { return age; }
	
	public int ageDifference(final Person other) {
		return age - other.age;
	}
	public String toString() {
		return String.format("%s - %d", name, age);
	}
}