import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Java8Code220JDBC_Lambda {

	@FunctionalInterface
	interface ResultSetProcessor {
	    public void process(ResultSet resultSet,  long currentRow, List<Emp> empList) 
	           throws SQLException;
	}
	
	public static List<Emp> select(Connection connection, String sql, ResultSetProcessor processor, Object... params) {
		List<Emp> empList = new ArrayList<Emp>();
		
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			int cnt = 0;
			for (Object param : params) {
			  ps.setObject(++cnt, param);
			}
			try (ResultSet rs = ps.executeQuery()) {
			  long rowCnt = 0;
			  while (rs.next()) {
			      processor.process(rs, rowCnt++, empList);
			  }
			  return empList;
			} catch (SQLException e) {
			  e.printStackTrace();
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) {
		Connection connect = null;
		
		System.out.println("In main.");
		
		try {
			connect = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "Scott", "lion");
			/*
			List<Emp> empList = select(connect, "select * from Emp",(rs, cnt, list)-> {
				Emp emp = new Emp(rs.getInt("EMPNO"), rs.getString("ENAME"), rs.getFloat("SAL"));
				list.add(emp);
			});
			*/
			///*
			 List<Emp> empList = select(connect, "select * from Emp where SAL>?",(rs, cnt, list) -> {
				Emp emp = new Emp(rs.getInt("EMPNO"), rs.getString("ENAME"), rs.getFloat("SAL"));
				list.add(emp);
			});
			//*/
			for(Emp emp : empList){
				System.out.println(emp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

class Emp {
	private int empNo;
	private String empNm;
	private float empSal;
	
	public Emp() {}
	
	public Emp(int empNo, String empNm, float empSal) {
		super();
		this.empNo = empNo;
		this.empNm = empNm;
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal=" + empSal + "]";
	}
}