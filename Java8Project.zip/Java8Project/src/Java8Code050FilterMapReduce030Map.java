import java.util.List;
import java.util.ArrayList;

public class Java8Code050FilterMapReduce030Map{
	private List<Integer> list;

	public Java8Code050FilterMapReduce030Map(){
		list = new ArrayList<>();
		list.add(10);
		list.add(30);
		list.add(20);
		list.add(50);
		list.add(70);
	}
	
	
	public List<Integer> getList() {
		return list;
	}


	public static void main(String[] argv){
		
		Java8Code050FilterMapReduce030Map listInt = new Java8Code050FilterMapReduce030Map();
		listInt.getList();
	}
}
