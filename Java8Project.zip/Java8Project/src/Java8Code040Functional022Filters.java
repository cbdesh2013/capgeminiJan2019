import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Java8Code040Functional022Filters {
	private static List<String> monthNames = Arrays.asList("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec");
	
	public static void main(String[] args) {
		/*
		List<String> startsWithN = new ArrayList<String>();
		for(String name : monthNames) {
			if(name.toUpperCase().startsWith("N")) {
				startsWithN.add(name);
			}
		}
		for(String name : startsWithN){
			System.out.println(name);
		}
		*/
		///*
		///* // The filter method takes lambda expression which returns null.  For elements for whom 
		List<String> startsWithN = monthNames.stream()
				.filter(name -> name.toUpperCase().startsWith("N"))
				.collect(Collectors.toList());
		//*/
		System.out.println(String.format("Found %d names", startsWithN.size()));
	}

}
