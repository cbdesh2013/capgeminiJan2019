import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Java8Code100DateTime {
	public static void main(String[] args) {
		/*
		// Current Instant time
		Instant currentTime = Instant.now();
		System.out.println("Case I.I: Current time through Instant: " + currentTime);
		
		// Java Epoch time
		Instant epochTime = Instant.EPOCH;  // Yug or Kaal
		Instant minTime   = Instant.MIN;
		Instant maxTime   = Instant.MAX;
		
		System.out.println("Case I.II: Epoch time through Instant: " + epochTime);
		System.out.println("Case I.III: Min time through Instant: " + minTime);
		System.out.println("Case I.VI: Max time through Instant: " + maxTime);
		
		// Arithmetic with Instant
		Instant twoMinsLater = currentTime.plusSeconds(120);
		System.out.println("Case I.VII: Time plus 2 Minutes: " + twoMinsLater);
		
		// Seconds elapsed since Epoch
		long secondsFromEpoch = Instant.ofEpochSecond(0L).until(currentTime, ChronoUnit.SECONDS);
		System.out.println("Case I.VIII: Elapsed Seconds: " + secondsFromEpoch);
		
		long milliSecondsFromEpoch = Instant.ofEpochMilli(0L).until(currentTime, ChronoUnit.MILLIS);
		System.out.println("Case I.IX: Elapsed MilliSeconds: " + milliSecondsFromEpoch);
		
		// Convert Instant to LocalDateTime.
		// LocalDateTime: Records date and time both.
		LocalDateTime localDateTime = LocalDateTime.ofInstant(Instant.now(),
				ZoneId.systemDefault());
		System.out.print("Case I.X: Date from LocalDateTime: ");
		System.out.println(localDateTime.getDayOfMonth() + "/"
				+ localDateTime.getMonth() + "/" + localDateTime.getYear());
		*/
		///*
		// LocalDate class- Does not record time.
		LocalDate today = LocalDate.now();
		System.out.println("Case I.XI: LocalDate: " + today);
		
		System.out.println("\n**************************************************\n");
		
		// LocalDate Parsing and Formatting.
		ZonedDateTime localDate1 = ZonedDateTime.now();
		System.out.println("Case II.I Current ZonedDateTime: " + localDate1);
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String dateInString = localDate1.format(formatter1);
		System.out.println("Case II.II Formatted ZonedDateTime: " + dateInString);
		
		// Formatting (Date and time)
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
		LocalDateTime localDateTime2 = LocalDateTime.now();
		String dateString = localDateTime2.format(formatter2);
		System.out.println("Case II.III Formatted LocalDateTime: " + dateString);
		
		// Parsing date
		String stringDate1 = "04/10/1989";// time not required.
		DateTimeFormatter formatter3 = DateTimeFormatter .ofPattern("dd/MM/yyyy");// must match the format of string input
											
		LocalDate date1 = LocalDate.parse(stringDate1, formatter3);
		System.out.println("Case II.IV Formatted ParsedDateTime: " +date1);
		
		// Parsing (String to Date with Time)
		String stringDate2 = "04/10/1989 21:30";// mandatory to give time with date
		DateTimeFormatter formatter4 = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");// this format must match the string input
		LocalDateTime date2 = LocalDateTime.parse(stringDate2, formatter4);
		System.out.println("Case II.V Formatted ParsedDateTime: " + date2);

		System.out.println("\n**************************************************\n");
		
		LocalDate localDate2 = LocalDate.now();
		LocalDate localDate3 = LocalDate.now().plusYears(1);
		
		// Is a leap year?
		if (localDate2.isLeapYear()) {
			System.out.println("Case III.I This year is a leap year.");
		} else {
			System.out.println("Case III.I This year is not a leap year.");
		}
		
		if (localDate3.isLeapYear()) {
			System.out.println("Case III.II Next year is a leap year.");
		} else {
			System.out.println("Case III.II Next year is not a leap year.");
		}
		
		// Create new instance of a date.
		LocalDate localDate4 = LocalDate.from(localDate3);
		System.out.println("Case III.IV New date instance: " + localDate4);
		//*/
		/*
		// Find duration between two dates...
		// Parsing date
		String stringDate2 = "04/10/2014";// time not required.
		DateTimeFormatter formatter5 = DateTimeFormatter.ofPattern("dd/MM/yyyy");// must match the format of string input
											
		LocalDate date2 = LocalDate.parse(stringDate2, formatter5);
		System.out.println("Case II.IV Formatted ParsedDateTime: " +date2);
		
		LocalDate date1 = LocalDate.now();
		Period period = date2.until(date1);
		System.out.println(period.getDays());
		System.out.println(period.getMonths());
		System.out.println(period.getYears());
		*/
	}
}
