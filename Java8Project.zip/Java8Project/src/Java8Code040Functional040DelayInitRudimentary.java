
public class Java8Code040Functional040DelayInitRudimentary {
	/* A holder class has two types of services...
	 	* Services quickly created and are not heavy-weight
		* Services heavy-weight consuming resources.
		Let us segregate these two services as...
		* Quick and light weight services within Holder class.
		* Heavy weight services within another class Help.
		Then we need to delay creation of Help class.
		
		Issues with following code...
			Its not thread safe and prone to race condition.  Concurrent calls to getHeavy() leads to multiple object creation.
			Can be made thread safe by declaring getHeavy() synchronized.
				But this approach creates another problem of bottleneck.  Each call will have to synthesis 'synchronize' even after creation first object.
				
	*/
	public static void main(String[] args) {
		HolderNaive holder = new HolderNaive();
		
		// Demand for Heavy.
		System.out.println("Demand for Heavy");
		Heavy1 heavy = holder.getHeavy();
	}
}

class HolderNaive {
	private Heavy1 heavy = null;
	
	public HolderNaive() {
		System.out.println("Holder created");
	}
	/*
	// Not thread safe...
	public Heavy getHeavy() {
		System.out.println("Non thread-safe approach");
		if(heavy == null) {
			heavy = new Heavy();
		}
		return heavy;
	}
	*/
	/*
	// Thread safe approach with bottleneck of synchronization
	public synchronized  Heavy getHeavy() {
		System.out.println("Thread safe approach with bottleneck of synchronization");
		if(heavy == null) {
			heavy = new Heavy();
		}
		return heavy;
	}
	*/
	// Thread safe approach with reduced overhead of synchronization
	public Heavy1 getHeavy() {
		System.out.println("Thread safe approach with doublecheck");
		if(heavy == null) {
			synchronized(this){
				if (heavy == null)
					heavy = new Heavy1();
			}
		}
		
		return heavy;
	}
}

class Heavy1 {
	public Heavy1() { 
		System.out.println("Heavy created");
	}
	public String toString() {
		return "quite heavy";
	}
}