import java.time.LocalDate;

public class Java8Code120Comparison {

	public static void main(String[] args) {
		LocalDate localDate1 = LocalDate.now();
		LocalDate localDate2 = LocalDate.now();
		LocalDate localDate3 = localDate2.plusDays(1);
		
		// Comparison for equality
		if (localDate1.equals(localDate2)) {
			System.out.println("Case I.I Both dates equal test Success" );
		} else {
			System.out.println("Case I.I Both dates equal test UnSuccess");
		}

		// Comparison for Un-equality
		if (localDate1.equals(localDate3)) {
			System.out.println("Case I.II Both dates equal test UnSuccess" );
		} else {
			System.out.println("Case I.II Both dates equal test Success");
		}
		
		// Comparison for Less than
		if (localDate1.isBefore(localDate3)) {
			System.out.println("Case I.III Both dates less than test Success" );
		} else {
			System.out.println("Case I.III Both dates less than test UnSuccess");
		}
		
		// Comparison for Greater than
		if (localDate1.isAfter(localDate3)) {
			System.out.println("Case I.III Both dates not greater than test USuccess" );
		} else {
			System.out.println("Case I.III Both dates not greater than test Success");
		}
		
		// Comparison using 'compareTo'
		if (localDate1.compareTo(localDate2) == 0) {
			System.out.println("Case I.IV Both dates equal test Success" );
		} else {
			System.out.println("Case I.IV Both dates equal test UnSuccess");
		}
		
		// Comparison using 'compareTo'
		if (localDate1.compareTo(localDate3) < 0) {
			System.out.println("Case I.V Both dates less than test Success" );
		} else {
			System.out.println("Case I.V Both dates less than test UnSuccess");
		}
		
		// Comparison using 'compareTo'
		if (localDate1.compareTo(localDate3) > 0) {
			System.out.println("Case I.VI Both dates less than test UnSuccess" );
		} else {
			System.out.println("Case I.VI Both dates less than test Success");
		}
		
	}
}
