import java.util.List;
import java.util.function.Consumer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class Java8Code040Functional020forEach {
	private List<Integer> listInt = Arrays.asList(20, 40, 10, 30, 5);

	public static void main(String[] argv){
		Java8Code040Functional020forEach oper = 
			new Java8Code040Functional020forEach();
		
		/*// Java legacy approach
		Iterator<Integer> iterate = oper.listInt.iterator();
		while(iterate.hasNext()){
			System.out.println(iterate.next());
		}
		*/
		
		/*// Java 5 approach of extended for loop
		// This approach expect less ceremony than earlier approach.
		for(Integer val : oper.listInt){
			System.out.println(val);
		}
		*/
		/*
		 //I want to see collection contents.  Why should I take help of third party for loop to see contents?
		 //In Java 8, Collections now implement Iterable and thus provide forEach().
		 
		oper.listInt.forEach(new Consumer<Integer>(){
			@Override
			public void accept(final Integer number) {
				System.out.println(number);
			}
		});
		*/
		/*
		 * If Consumer interface has a single method, why do I need to define method?
		 */
		//oper.listInt.forEach(System.out::println);
		//oper.listInt.forEach(number->System.out.println("Value :" + number));
		
	}
}

