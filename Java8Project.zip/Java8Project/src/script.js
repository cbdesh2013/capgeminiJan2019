var fun1 = function(name) {
    print('Hi there from Javascript, ' + name);
    return "greetings from javascript";
};

var fun2 = function (object) {
    print("JS Class Definition: " + Object.prototype.toString.call(object));
};

var fun3 = function (object) {
	var MyJavaClass = Java.type('Java8Code300Nashhorn010'); // It should be fully qualified name of a class.
	
	var result = MyJavaClass.javaMethod(object);
	print(result);
	return result;
};