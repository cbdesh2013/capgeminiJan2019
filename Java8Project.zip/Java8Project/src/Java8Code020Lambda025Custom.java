interface MyProcessor1 {
	void process(String value);
}

public class Java8Code020Lambda025Custom {

	public void execute(MyProcessor1 processor, String msg){
		processor.process(msg);
	}

	public static void main(String[] args) {
		
	Java8Code020Lambda025Custom executor = new Java8Code020Lambda025Custom();
		/*
		// Implementation of SAM interface.
		MyProcessor1 processor = new MyProcessor1() {
			@Override
			public void process(String value) {
				System.out.println("AnnClass: "+value);
			}
		};
		executor.execute(processor, "Hello");
		*/

		/*
		// Syntax 1
		MyProcessor1 processor = (param) -> {
			System.out.println("Syntax1: "+param);
		};
		executor.execute(processor, "Hello");
		*/

		/*
		// Syntax2: For transformation in param.
		executor.execute((param)-> {
			System.out.println("Syntax2: "+param);
		}, "Hello");
		
		*/

		///*
		// Syntax3: No transformation is allowed in param.
		executor.execute(System.out::println, "Hello");
		//*/
	}
}