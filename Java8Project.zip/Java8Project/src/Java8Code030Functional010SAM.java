import java.lang.FunctionalInterface;

/*
 * The custom functional interface
 * 		Its of type Single Abstract Method.  Does not allow any other abstract method.
 * 		It allows default method/s.  
 * 		the default method is non-staic and non-abstract thus can be called on an implementing class object.
 */
public class Java8Code030Functional010SAM{
	public static void main(String[] args) {
		AnyFunctionalInterface afi = (param) -> "Hello :" + param;
		System.out.println(afi.process1("Chandra"));
		System.out.println(afi.process2());
	}
}

@ FunctionalInterface
interface AnyFunctionalInterface {
	String process1(String value);
	//String process2(String value);
	default String process2(){ return "Any Value"; }
}


