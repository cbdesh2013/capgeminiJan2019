import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Java8Code040Functional024PickValue {

	private static List<String> monthNames = Arrays.asList("january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december");
	private static List<String> emptyList = new ArrayList<>();
	public static void main(String[] args) {
		String searchChar = "n";
		
		///*
		// Search with old way.
		String foundName = pickNameOldWay(monthNames, searchChar);
		String searchStatus = (foundName == null) ? "Name not found" : foundName;
		System.out.println(String.format("Name starting with %s is: %s", searchChar, searchStatus));
		//*/
		/*
		// Search with Optional object with orElse()
		String foundName = pickNameWithOptional1(monthNames, searchChar);
		System.out.println(String.format("Name starting with %s is: %s", searchChar, foundName));
		*/
		///*
		// Search with Optional object with ifPresent()
		pickNameWithOptional2(monthNames, searchChar).ifPresent(name -> System.out.println("Hello " + name));
		//*/
		
		
		// Reducing collection to a single value
		// Summing up total number of characters.
		System.out.println("Total number of characters in all names: " +
				monthNames.stream()
				.mapToInt(name -> name.length())
				.sum());
		
		System.out.println("Average number of characters in all names: " +
				monthNames.stream()
				.mapToInt(name -> name.length())
				.average().getAsDouble());
		
		System.out.println("Maximum number of characters in all names: " +
				monthNames.stream()
				.mapToInt(name -> name.length())
				.max().getAsInt());
		
		System.out.println("Sorted number of characters in all names: " +
				monthNames.stream()
				.mapToInt(name -> name.length())
				.sorted());
		
		// Use reducer to find longest name.
		// Try a reducer on empty list also to understand purpose of Optional return type of reduce().
		final Optional<String> aLongName =
				monthNames.stream()
				.reduce((name1, name2) ->
				name1.length() >= name2.length() ? name1 : name2);
		System.out.println(aLongName.orElse("Empty Collection."));
		
		// The reduce() with default value...
		final String aShortName =
				monthNames.stream()
				.reduce("january", (name1, name2) ->
				name1.length() <= name2.length() ? name1 : name2);
		System.out.println(String.format("Smallest month name with default %s", aShortName));
	}

	public static String pickNameOldWay(final List<String> names, final String startingLetter) {
		String foundName = null;
		for(String name : names) {
			if(name.startsWith(startingLetter)) {
				foundName = name;
				break;
			}
		}
		
		return foundName;
	}
	
	public static String pickNameWithOptional1(final List<String> names, final String startingLetter) {
		
		final Optional<String> foundName =names.stream()
				.filter(name ->name.startsWith(startingLetter))
				.findFirst();
		
		return foundName.orElse("Name not found");
	}
	
	public static Optional<String> pickNameWithOptional2(final List<String> names, final String startingLetter) {
		
		final Optional<String> foundName =names.stream()
				.filter(name ->name.startsWith(startingLetter))
				.findFirst();
		
		return foundName;
	}
}