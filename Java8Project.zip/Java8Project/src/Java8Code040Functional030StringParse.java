
public class Java8Code040Functional030StringParse {

	public static void main(String[] args) {
		final String str = "Quick Brown Fox jumped out of the wall and called emergency number 123";
		/*
		// Old way to traverse string
		for(int idx=0; idx<str.length(); idx++){
			System.out.print(str.charAt(idx));
		}
		*/
		// The new function chars() from String class.
		// The chars() returns a Stream of integers where each integer is an ASCII of a character.
		
		// Using Lambda Expression
		//str.chars().forEach(ch -> System.out.print((char)ch));
		
		// Using method reference
		//str.chars().forEach(System.out::print);
		
		// Using Map
		//str.chars().map(ch -> Character.valueOf((char)ch)).forEach(System.out::print);
		
		// Using reference of custom method
		//str.chars().forEach(IterateString::printChar);
		
		// Filtering for digits using Lambda Expression
		//str.chars().filter(ch -> Character.isDigit(ch)).forEach(IterateString::printChar);
		
		// Filtering for digits using method reference
		//str.chars().filter(Character::isDigit).forEach(IterateString::printChar);
	}
}

class IterateString{
	public static void printChar(int aChar) {
		System.out.print((char)(aChar));
	}
}
