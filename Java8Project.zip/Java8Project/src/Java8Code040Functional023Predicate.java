import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Java8Code040Functional023Predicate {

	public static void main(String[] args) {
		final List<String> friends = Arrays.asList("Brian", "Nate", "Neal", "Raju", "Sara", "Scott");
		final List<String> comrades = Arrays.asList("Kate", "Ken", "Nick", "Paula", "Zach");
		final List<String> editors = Arrays.asList("Brian", "Jackie", "John", "Mike");
		
		/* // Duplication of Lambda Expression
		final long countFriendsStartN = friends.stream().filter(name -> name.startsWith("N")).count();
		final long countComradesStartN = comrades.stream().filter(name -> name.startsWith("N")).count();
		final long countEditorsStartN = editors.stream().filter(name -> name.startsWith("N")).count();
		*/
		/* // Using Predicate
		final Predicate<String> startsWithN = name -> name.startsWith("N");
		final long countFriendsStartN = friends.stream().filter(startsWithN).count();
		final long countComradesStartN = comrades.stream().filter(startsWithN).count();
		final long countEditorsStartN = editors.stream().filter(startsWithN).count();
		*/
		/*
		System.out.println("Count of 'N' within friends: " + countFriendsStartN);
		System.out.println("Count of 'N' within comrades: " + countComradesStartN);
		System.out.println("Count of 'N' within editors: " + countEditorsStartN);
		*/
		/*
		// Duplication in Lambda Expression
		final Predicate<String> startsWithN2 = name -> name.startsWith("N");
		final Predicate<String> startsWithB2 = name -> name.startsWith("B");
		final long countFriendsStartN2 = friends.stream().filter(startsWithN2).count();
		final long countFriendsStartB2 = friends.stream().filter(startsWithB2).count();
		
		System.out.println("Count of 'N' within friends: " + countFriendsStartN2);
		System.out.println("Count of 'B' within friends: " + countFriendsStartB2);
		*/
		// Lexical Scoping
		String letter1 = "N";
		Predicate<String> startWithChar = getPredicate(letter1);
		System.out.println("Count of 'N' within friends: " + friends.stream().filter(startWithChar).count());
	}
	
	public static Predicate<String> getPredicate(String letter){
		return name -> name.startsWith(letter);
	}
}
