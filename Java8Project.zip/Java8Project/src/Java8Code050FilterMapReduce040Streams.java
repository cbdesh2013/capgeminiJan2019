import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;



public class Java8Code050FilterMapReduce040Streams {

	public static void main(String[] args) {
		List<String> months = new ArrayList<String>();
		months.add("cc");
		months.add("aa");
		months.add("dd");
		months.add("bb");
		
		//Stream stream = months.stream();
		Stream<String> pStream = months.parallelStream();
		
		//pStream.forEach(System.out::print);
		//pStream.forEach(System.out::print);  // Stream is not re-usable.  throws exception.
		
		//pStream.forEach(s -> System.out.println("*" + s + "*"));
		
		pStream = pStream.sorted();
		pStream.forEach(System.out::print);
	}
	

}
