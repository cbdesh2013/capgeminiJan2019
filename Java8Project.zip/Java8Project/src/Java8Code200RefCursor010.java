import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import oracle.jdbc.OracleTypes;

public class Java8Code200RefCursor010 {

	public static void main(String[] args) {
		Connection connect = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		System.out.println("In main.");
		try {
			
			connect = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "Scott", "lion");
			DatabaseMetaData dbmd = connect.getMetaData();
			boolean supportRefCursor = dbmd.supportsRefCursors();
			
			System.out.println("Is this driver support a Ref Cursor?" + supportRefCursor);
			
			cs = connect.prepareCall("{call getEmpCursor(?, ?)}");
			   
 		   cs.setInt(1, 2000);
 		   System.out.println("Parameter Registered.");
 		   
 		   if (supportRefCursor){
 			  System.out.println("Using standard support for RefCursor.");
 			 cs.registerOutParameter(2, Types.REF_CURSOR); 
 		   } else {
 			   System.out.println("Using DB specific support for RefCursor."); //Support not available in ojdbc6.jar: java.sql.Types.REF_CURSOR
 			   cs.registerOutParameter(2, OracleTypes.CURSOR); 
 		   }
 		  
 		   System.out.println("Procedure Called.");
 		   cs.executeUpdate();
 		   
 		  rs = (ResultSet) cs.getObject(2);
 		  
 		  System.out.println("Records...");
		   while (rs.next()){
			   int empNo = rs.getInt("EMPNO");
			   String empNm = rs.getString("ENAME");
			   float empSal = rs.getFloat("SAL");
			   
			   System.out.println(empNo+" "+empNm+" "+empSal);
		   }
		   
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null){
					rs.close();
				}
				if (cs != null){
					cs.close();
				}
				if (connect != null){
					connect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
