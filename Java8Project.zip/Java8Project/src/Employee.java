
public class Employee {
	private int empNo;
	private float empSal;
	private int deptNo;
	
	public Employee(int empNo, float empSal, int deptNo){
		this.empNo = empNo;
		this.empSal = empSal;
		this.deptNo = deptNo;
	}

	public float getEmpSal() {
		return empSal;
	}

	public int getDeptNo() {
		return deptNo;
	}

	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", empSal=" + empSal + ", deptNo=" + deptNo + "]";
	}
}
