import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class Java8Code040Functional027Collectors {
	private static List<String> monthNames = Arrays.asList("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec");
	private static List<Integer> monthDays = Arrays.asList(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
	
	public static void main(String[] args) {
		/*
		// Map to List collector.
		List<String> strings = monthNames.stream()
				.map(name -> name.toUpperCase()).collect(Collectors.toList());
				//.map(name -> name.toUpperCase()).collect(Collectors.toCollection(ArrayList::new));
				//.map(name -> name.toUpperCase()).collect(Collectors.toCollection(LinkedList::new));
		*/
		/*
		// Map to Set collector.
		Set<String> strings = monthNames.stream()
				.map(String::toUpperCase).collect(Collectors.toCollection(TreeSet::new));
				//.map(String::toUpperCase).collect(Collectors.toSet());
		*/
		
		/*
		// The joined string with Collector.
		String joined = monthDays.stream()
                .map(Object::toString)
                .collect(Collectors.joining(", "));
		*/
		
		/*
		// Filter to collector.
		List<String> strings = monthNames.stream()
				.filter(name -> name.toUpperCase().startsWith("N"))
				.collect(Collectors.toList());
		*/
		//System.out.println(String.format("Found %d names", strings.size()));
		//System.out.println(joined);
		
		//************ Operations with Employee list *************
		List<Employee> empList = Arrays.asList(
				new Employee(100, 30000, 10),
				new Employee(110, 25000, 20),
				new Employee(102, 27000, 10),
				new Employee(115, 29000, 30)
				);
		
		/*
		// Summing salary.
		 double totalSal = empList.stream()
                 .collect(Collectors.summingDouble(Employee::getEmpSal));
		 System.out.println(totalSal);
		*/
		 /*
		 Map<Integer, List<Employee>> byDept
         = empList.stream()
                    .collect(Collectors.groupingBy(Employee::getDeptNo));
		 System.out.println(byDept);
		 */
		 /*
		 Map<Boolean, List<Employee>> salaryThrishold =
				 empList.stream()
		                 .collect(Collectors.partitioningBy(s -> s.getEmpSal() >= 27000));
		 System.out.println(salaryThrishold);
		 */
	}
}
/*
class Employee {
	private int empNo;
	private float empSal;
	private int deptNo;
	
	public Employee(int empNo, float empSal, int deptNo){
		this.empNo = empNo;
		this.empSal = empSal;
		this.deptNo = deptNo;
	}

	public float getEmpSal() {
		return empSal;
	}

	public int getDeptNo() {
		return deptNo;
	}

	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", empSal=" + empSal + ", deptNo=" + deptNo + "]";
	}
}*/
/*
// Accumulate names into a List
     List<String> list = people.stream().map(Person::getName).collect(Collectors.toList());

     // Accumulate names into a TreeSet
     Set<String> set = people.stream().map(Person::getName).collect(Collectors.toCollection(TreeSet::new));

     // Convert elements to strings and concatenate them, separated by commas
     String joined = things.stream()
                           .map(Object::toString)
                           .collect(Collectors.joining(", "));

     // Compute sum of salaries of employee
     int total = employees.stream()
                          .collect(Collectors.summingInt(Employee::getSalary)));

     // Group employees by department
     Map<Department, List<Employee>> byDept
         = employees.stream()
                    .collect(Collectors.groupingBy(Employee::getDepartment));

     // Compute sum of salaries by department
     Map<Department, Integer> totalByDept
         = employees.stream()
                    .collect(Collectors.groupingBy(Employee::getDepartment,
                                                   Collectors.summingInt(Employee::getSalary)));

     // Partition students into passing and failing
     Map<Boolean, List<Student>> passingFailing =
         students.stream()
                 .collect(Collectors.partitioningBy(s -> s.getGrade() >= PASS_THRESHOLD));

*/